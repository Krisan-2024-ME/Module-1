/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<stdio.h>
#include<unistd.h>
int main(){
    float pi;
    float radius;
    float area;
    printf("Enter the valu of pi ");
    scanf("%f",&pi);
    printf("Enter the valu radius ");
    scanf("%f",&radius);
    area = pi*radius*radius;
    printf("Area of circle is %.2f squar unit.",area);
    return 0;
}